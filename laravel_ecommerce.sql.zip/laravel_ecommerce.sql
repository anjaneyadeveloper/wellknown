-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2019 at 05:55 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `le_addresses`
--

CREATE TABLE `le_addresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` enum('SHIPPING','BILLING') COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_admin_password_resets`
--

CREATE TABLE `le_admin_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_admin_users`
--

CREATE TABLE `le_admin_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_super_admin` tinyint(4) DEFAULT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'en',
  `image_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_admin_users`
--

INSERT INTO `le_admin_users` (`id`, `is_super_admin`, `role_id`, `first_name`, `last_name`, `email`, `password`, `language`, `image_path`, `remember_token`, `email_verified_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Karthik', 'Raja C', 'karthikraja.ckr@gmail.com', '$2y$10$XCohMLehnfdvetOP5yCklu62CiApnPhoOdO7qIBofqXFCXRKb65ra', 'en', NULL, 'EkpBnGyn6auplsuoW8t16gZj19nco4oCFei1sCk2kZrsItBWDEakkTOkK5tk', NULL, '2019-05-01 07:03:39', '2019-05-01 07:03:39');

-- --------------------------------------------------------

--
-- Table structure for table `le_attributes`
--

CREATE TABLE `le_attributes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_attribute_dropdown_options`
--

CREATE TABLE `le_attribute_dropdown_options` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(10) UNSIGNED NOT NULL,
  `display_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_attribute_dropdown_option_translations`
--

CREATE TABLE `le_attribute_dropdown_option_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_dropdown_option_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `display_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_attribute_product`
--

CREATE TABLE `le_attribute_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_attribute_translations`
--

CREATE TABLE `le_attribute_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_banners`
--

CREATE TABLE `le_banners` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alt_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('ENABLED','DISABLED') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ENABLED',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_banners`
--

INSERT INTO `le_banners` (`id`, `name`, `image_path`, `alt_text`, `url`, `target`, `status`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Kitchen Sale', 'uploads/cms/images/b/k/o/TIydVFNLKKJTiqJjUa29LKdVH0sgxadTJGogzGuI.jpeg', 'Kitchen On Sale', 'category/kitchen', NULL, 'ENABLED', 10, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(2, 'Living Room On Sale', 'uploads/cms/images/y/v/u/CqQjp5hSvRFnx0glalLnpTP7F1PLOCGoLAMPtnmc.jpeg', 'Living Room Items on Sale', 'category/living-room', NULL, 'ENABLED', 20, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(3, 'Bedroom Sale', 'uploads/cms/images/n/k/q/txdsemPHuXC9CHvXrXB7vvRVZc4C0YhrOrr4v1Su.jpeg', 'Bedroom On Sale', 'category/bedroom', NULL, 'ENABLED', 30, '2019-05-01 06:57:06', '2019-05-01 06:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `le_categories`
--

CREATE TABLE `le_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_categories`
--

INSERT INTO `le_categories` (`id`, `parent_id`, `name`, `slug`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Kitchen', 'kitchen', NULL, NULL, '2019-05-01 06:57:00', '2019-05-01 06:57:00'),
(2, NULL, 'Bedroom', 'bedroom', NULL, NULL, '2019-05-01 06:57:00', '2019-05-01 06:57:00'),
(3, NULL, 'Living Room', 'living-room', NULL, NULL, '2019-05-01 06:57:01', '2019-05-01 06:57:01');

-- --------------------------------------------------------

--
-- Table structure for table `le_category_filters`
--

CREATE TABLE `le_category_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `type` enum('ATTRIBUTE','PROPERTY') COLLATE utf8_unicode_ci DEFAULT NULL,
  `filter_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_category_product`
--

CREATE TABLE `le_category_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_category_product`
--

INSERT INTO `le_category_product` (`id`, `category_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, NULL, NULL),
(2, 3, 2, NULL, NULL),
(3, 3, 3, NULL, NULL),
(4, 3, 4, NULL, NULL),
(5, 3, 5, NULL, NULL),
(6, 3, 6, NULL, NULL),
(7, 2, 7, NULL, NULL),
(8, 2, 8, NULL, NULL),
(9, 2, 9, NULL, NULL),
(10, 2, 10, NULL, NULL),
(11, 1, 11, NULL, NULL),
(12, 1, 12, NULL, NULL),
(13, 1, 13, NULL, NULL),
(14, 1, 14, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `le_category_translations`
--

CREATE TABLE `le_category_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_configurations`
--

CREATE TABLE `le_configurations` (
  `id` int(10) UNSIGNED NOT NULL,
  `configuration_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration_value` varchar(999) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_configurations`
--

INSERT INTO `le_configurations` (`id`, `configuration_key`, `configuration_value`, `created_at`, `updated_at`) VALUES
(1, 'general_site_currency', '1', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(2, 'tax_default_country', '160', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(3, 'tax_enabled', '1', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(4, 'tax_percentage', '15', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(5, 'general_site_title', 'AvoRed an Laravel Ecommerce', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(6, 'general_site_description', 'AvoRed is a free open-source e-commerce application development platform written in PHP based on Laravel. Its an ingenuous and modular e-commerce that is easily customizable according to your needs, with a modern responsive mobile friendly interface as default', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(7, 'general_site_description', 'AvoRed Laravel Ecommerce\n        ', '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(8, 'general_home_page', '1', '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(9, 'shipping_free_shipping_enabled', '1', '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(10, 'payment_pickup_enabled', '1', '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(11, 'general_term_condition_page', '2', '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(12, 'active_theme_identifier', 'avored-default', '2019-05-01 06:57:16', '2019-05-01 06:57:16'),
(13, 'active_theme_path', 'E:\\NewPHP\\xampp\\htdocs\\laravel-ecommerce\\themes\\avored\\default', '2019-05-01 06:57:16', '2019-05-01 06:57:16'),
(14, 'avored_catalog_no_of_product_category_page', '9', '2019-05-01 06:57:16', '2019-05-01 06:57:16'),
(15, 'avored_catalog_cart_page_display_taxamount', 'yes', '2019-05-01 06:57:17', '2019-05-01 06:57:17'),
(16, 'avored_tax_class_percentage_of_tax', '15', '2019-05-01 06:57:17', '2019-05-01 06:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `le_countries`
--

CREATE TABLE `le_countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_countries`
--

INSERT INTO `le_countries` (`id`, `code`, `name`, `phone_code`, `currency_code`, `currency_symbol`, `lang_code`, `created_at`, `updated_at`) VALUES
(1, 'af', 'Afghanistan', '93', 'AFN', '؋', 'Pashto', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(2, 'ax', 'Åland Islands', '358', 'EUR', '€', 'Swedish', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(3, 'al', 'Albania', '355', 'ALL', 'L', 'Albanian', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(4, 'dz', 'Algeria', '213', 'DZD', 'د.ج', 'Arabic', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(5, 'as', 'American Samoa', '1684', 'USD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(6, 'ad', 'Andorra', '376', 'EUR', '€', 'Catalan', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(7, 'ao', 'Angola', '244', 'AOA', 'Kz', 'Portuguese', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(8, 'ai', 'Anguilla', '1264', 'XCD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(9, 'aq', 'Antarctica', '672', 'AUD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(10, 'ag', 'Antigua and Barbuda', '1268', 'XCD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(11, 'ar', 'Argentina', '54', 'ARS', '$', 'Spanish', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(12, 'am', 'Armenia', '374', 'AMD', NULL, 'Armenian', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(13, 'aw', 'Aruba', '297', 'AWG', 'ƒ', 'Dutch', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(14, 'au', 'Australia', '61', 'AUD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(15, 'at', 'Austria', '43', 'EUR', '€', 'German', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(16, 'az', 'Azerbaijan', '994', 'AZN', NULL, 'Azerbaijani', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(17, 'bs', 'Bahamas', '1242', 'BSD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(18, 'bh', 'Bahrain', '973', 'BHD', '.د.ب', 'Arabic', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(19, 'bd', 'Bangladesh', '880', 'BDT', '৳', 'Bengali', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(20, 'bb', 'Barbados', '1246', 'BBD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(21, 'by', 'Belarus', '375', 'BYN', 'Br', 'Belarusian', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(22, 'be', 'Belgium', '32', 'EUR', '€', 'Dutch', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(23, 'bz', 'Belize', '501', 'BZD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(24, 'bj', 'Benin', '229', 'XOF', 'Fr', 'French', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(25, 'bm', 'Bermuda', '1441', 'BMD', '$', 'English', '2019-05-01 06:56:34', '2019-05-01 06:56:34'),
(26, 'bt', 'Bhutan', '975', 'BTN', 'Nu.', 'Dzongkha', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(27, 'bo', 'Bolivia (Plurinational State of)', '591', 'BOB', 'Bs.', 'Spanish', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(28, 'bq', 'Bonaire, Sint Eustatius and Saba', '5997', 'USD', '$', 'Dutch', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(29, 'ba', 'Bosnia and Herzegovina', '387', 'BAM', NULL, 'Bosnian', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(30, 'bw', 'Botswana', '267', 'BWP', 'P', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(31, 'bv', 'Bouvet Island', '', 'NOK', 'kr', 'Norwegian', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(32, 'br', 'Brazil', '55', 'BRL', 'R$', 'Portuguese', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(33, 'io', 'British Indian Ocean Territory', '246', 'USD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(34, 'um', 'United States Minor Outlying Islands', '', 'USD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(35, 'vg', 'Virgin Islands (British)', '1284', NULL, '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(36, 'vi', 'Virgin Islands (U.S.)', '1 340', 'USD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(37, 'bn', 'Brunei Darussalam', '673', 'BND', '$', 'Malay', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(38, 'bg', 'Bulgaria', '359', 'BGN', 'лв', 'Bulgarian', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(39, 'bf', 'Burkina Faso', '226', 'XOF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(40, 'bi', 'Burundi', '257', 'BIF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(41, 'kh', 'Cambodia', '855', 'KHR', '៛', 'Khmer', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(42, 'cm', 'Cameroon', '237', 'XAF', 'Fr', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(43, 'ca', 'Canada', '1', 'CAD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(44, 'cv', 'Cabo Verde', '238', 'CVE', 'Esc', 'Portuguese', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(45, 'ky', 'Cayman Islands', '1345', 'KYD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(46, 'cf', 'Central African Republic', '236', 'XAF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(47, 'td', 'Chad', '235', 'XAF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(48, 'cl', 'Chile', '56', 'CLP', '$', 'Spanish', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(49, 'cn', 'China', '86', 'CNY', '¥', 'Chinese', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(50, 'cx', 'Christmas Island', '61', 'AUD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(51, 'cc', 'Cocos (Keeling) Islands', '61', 'AUD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(52, 'co', 'Colombia', '57', 'COP', '$', 'Spanish', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(53, 'km', 'Comoros', '269', 'KMF', 'Fr', 'Arabic', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(54, 'cg', 'Congo', '242', 'XAF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(55, 'cd', 'Congo (Democratic Republic of the)', '243', 'CDF', 'Fr', 'French', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(56, 'ck', 'Cook Islands', '682', 'NZD', '$', 'English', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(57, 'cr', 'Costa Rica', '506', 'CRC', '₡', 'Spanish', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(58, 'hr', 'Croatia', '385', 'HRK', 'kn', 'Croatian', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(59, 'cu', 'Cuba', '53', 'CUC', '$', 'Spanish', '2019-05-01 06:56:35', '2019-05-01 06:56:35'),
(60, 'cw', 'Curaçao', '599', 'ANG', 'ƒ', 'Dutch', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(61, 'cy', 'Cyprus', '357', 'EUR', '€', 'Greek (modern)', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(62, 'cz', 'Czech Republic', '420', 'CZK', 'Kč', 'Czech', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(63, 'dk', 'Denmark', '45', 'DKK', 'kr', 'Danish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(64, 'dj', 'Djibouti', '253', 'DJF', 'Fr', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(65, 'dm', 'Dominica', '1767', 'XCD', '$', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(66, 'do', 'Dominican Republic', '1809', 'DOP', '$', 'Spanish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(67, 'ec', 'Ecuador', '593', 'USD', '$', 'Spanish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(68, 'eg', 'Egypt', '20', 'EGP', '£', 'Arabic', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(69, 'sv', 'El Salvador', '503', 'USD', '$', 'Spanish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(70, 'gq', 'Equatorial Guinea', '240', 'XAF', 'Fr', 'Spanish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(71, 'er', 'Eritrea', '291', 'ERN', 'Nfk', 'Tigrinya', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(72, 'ee', 'Estonia', '372', 'EUR', '€', 'Estonian', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(73, 'et', 'Ethiopia', '251', 'ETB', 'Br', 'Amharic', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(74, 'fk', 'Falkland Islands (Malvinas)', '500', 'FKP', '£', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(75, 'fo', 'Faroe Islands', '298', 'DKK', 'kr', 'Faroese', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(76, 'fj', 'Fiji', '679', 'FJD', '$', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(77, 'fi', 'Finland', '358', 'EUR', '€', 'Finnish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(78, 'fr', 'France', '33', 'EUR', '€', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(79, 'gf', 'French Guiana', '594', 'EUR', '€', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(80, 'pf', 'French Polynesia', '689', 'XPF', 'Fr', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(81, 'tf', 'French Southern Territories', '', 'EUR', '€', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(82, 'ga', 'Gabon', '241', 'XAF', 'Fr', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(83, 'gm', 'Gambia', '220', 'GMD', 'D', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(84, 'ge', 'Georgia', '995', 'GEL', 'ლ', 'Georgian', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(85, 'de', 'Germany', '49', 'EUR', '€', 'German', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(86, 'gh', 'Ghana', '233', 'GHS', '₵', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(87, 'gi', 'Gibraltar', '350', 'GIP', '£', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(88, 'gr', 'Greece', '30', 'EUR', '€', 'Greek (modern)', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(89, 'gl', 'Greenland', '299', 'DKK', 'kr', 'Kalaallisut', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(90, 'gd', 'Grenada', '1473', 'XCD', '$', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(91, 'gp', 'Guadeloupe', '590', 'EUR', '€', 'French', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(92, 'gu', 'Guam', '1671', 'USD', '$', 'English', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(93, 'gt', 'Guatemala', '502', 'GTQ', 'Q', 'Spanish', '2019-05-01 06:56:36', '2019-05-01 06:56:36'),
(94, 'gg', 'Guernsey', '44', 'GBP', '£', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(95, 'gn', 'Guinea', '224', 'GNF', 'Fr', 'French', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(96, 'gw', 'Guinea-Bissau', '245', 'XOF', 'Fr', 'Portuguese', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(97, 'gy', 'Guyana', '592', 'GYD', '$', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(98, 'ht', 'Haiti', '509', 'HTG', 'G', 'French', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(99, 'hm', 'Heard Island and McDonald Islands', '', 'AUD', '$', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(100, 'va', 'Holy See', '379', 'EUR', '€', 'Latin', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(101, 'hn', 'Honduras', '504', 'HNL', 'L', 'Spanish', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(102, 'hk', 'Hong Kong', '852', 'HKD', '$', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(103, 'hu', 'Hungary', '36', 'HUF', 'Ft', 'Hungarian', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(104, 'is', 'Iceland', '354', 'ISK', 'kr', 'Icelandic', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(105, 'in', 'India', '91', 'INR', '₹', 'Hindi', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(106, 'id', 'Indonesia', '62', 'IDR', 'Rp', 'Indonesian', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(107, 'ci', 'Côte d\'Ivoire', '225', 'XOF', 'Fr', 'French', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(108, 'ir', 'Iran (Islamic Republic of)', '98', 'IRR', '﷼', 'Persian (Farsi)', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(109, 'iq', 'Iraq', '964', 'IQD', 'ع.د', 'Arabic', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(110, 'ie', 'Ireland', '353', 'EUR', '€', 'Irish', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(111, 'im', 'Isle of Man', '44', 'GBP', '£', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(112, 'il', 'Israel', '972', 'ILS', '₪', 'Hebrew (modern)', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(113, 'it', 'Italy', '39', 'EUR', '€', 'Italian', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(114, 'jm', 'Jamaica', '1876', 'JMD', '$', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(115, 'jp', 'Japan', '81', 'JPY', '¥', 'Japanese', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(116, 'je', 'Jersey', '44', 'GBP', '£', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(117, 'jo', 'Jordan', '962', 'JOD', 'د.ا', 'Arabic', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(118, 'kz', 'Kazakhstan', '76', 'KZT', NULL, 'Kazakh', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(119, 'ke', 'Kenya', '254', 'KES', 'Sh', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(120, 'ki', 'Kiribati', '686', 'AUD', '$', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(121, 'kw', 'Kuwait', '965', 'KWD', 'د.ك', 'Arabic', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(122, 'kg', 'Kyrgyzstan', '996', 'KGS', 'с', 'Kyrgyz', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(123, 'la', 'Lao People\'s Democratic Republic', '856', 'LAK', '₭', 'Lao', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(124, 'lv', 'Latvia', '371', 'EUR', '€', 'Latvian', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(125, 'lb', 'Lebanon', '961', 'LBP', 'ل.ل', 'Arabic', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(126, 'ls', 'Lesotho', '266', 'LSL', 'L', 'English', '2019-05-01 06:56:37', '2019-05-01 06:56:37'),
(127, 'lr', 'Liberia', '231', 'LRD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(128, 'ly', 'Libya', '218', 'LYD', 'ل.د', 'Arabic', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(129, 'li', 'Liechtenstein', '423', 'CHF', 'Fr', 'German', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(130, 'lt', 'Lithuania', '370', 'EUR', '€', 'Lithuanian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(131, 'lu', 'Luxembourg', '352', 'EUR', '€', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(132, 'mo', 'Macao', '853', 'MOP', 'P', 'Chinese', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(133, 'mk', 'Macedonia (the former Yugoslav Republic of)', '389', 'MKD', 'ден', 'Macedonian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(134, 'mg', 'Madagascar', '261', 'MGA', 'Ar', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(135, 'mw', 'Malawi', '265', 'MWK', 'MK', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(136, 'my', 'Malaysia', '60', 'MYR', 'RM', 'Malaysian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(137, 'mv', 'Maldives', '960', 'MVR', '.ރ', 'Divehi', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(138, 'ml', 'Mali', '223', 'XOF', 'Fr', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(139, 'mt', 'Malta', '356', 'EUR', '€', 'Maltese', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(140, 'mh', 'Marshall Islands', '692', 'USD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(141, 'mq', 'Martinique', '596', 'EUR', '€', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(142, 'mr', 'Mauritania', '222', 'MRO', 'UM', 'Arabic', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(143, 'mu', 'Mauritius', '230', 'MUR', '₨', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(144, 'yt', 'Mayotte', '262', 'EUR', '€', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(145, 'mx', 'Mexico', '52', 'MXN', '$', 'Spanish', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(146, 'fm', 'Micronesia (Federated States of)', '691', NULL, '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(147, 'md', 'Moldova (Republic of)', '373', 'MDL', 'L', 'Romanian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(148, 'mc', 'Monaco', '377', 'EUR', '€', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(149, 'mn', 'Mongolia', '976', 'MNT', '₮', 'Mongolian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(150, 'me', 'Montenegro', '382', 'EUR', '€', 'Serbian', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(151, 'ms', 'Montserrat', '1664', 'XCD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(152, 'ma', 'Morocco', '212', 'MAD', 'د.م.', 'Arabic', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(153, 'mz', 'Mozambique', '258', 'MZN', 'MT', 'Portuguese', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(154, 'mm', 'Myanmar', '95', 'MMK', 'Ks', 'Burmese', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(155, 'na', 'Namibia', '264', 'NAD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(156, 'nr', 'Nauru', '674', 'AUD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(157, 'np', 'Nepal', '977', 'NPR', '₨', 'Nepali', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(158, 'nl', 'Netherlands', '31', 'EUR', '€', 'Dutch', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(159, 'nc', 'New Caledonia', '687', 'XPF', 'Fr', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(160, 'nz', 'New Zealand', '64', 'NZD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(161, 'ni', 'Nicaragua', '505', 'NIO', 'C$', 'Spanish', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(162, 'ne', 'Niger', '227', 'XOF', 'Fr', 'French', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(163, 'ng', 'Nigeria', '234', 'NGN', '₦', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(164, 'nu', 'Niue', '683', 'NZD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(165, 'nf', 'Norfolk Island', '672', 'AUD', '$', 'English', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(166, 'kp', 'Korea (Democratic People\'s Republic of)', '850', 'KPW', '₩', 'Korean', '2019-05-01 06:56:38', '2019-05-01 06:56:38'),
(167, 'mp', 'Northern Mariana Islands', '1670', 'USD', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(168, 'no', 'Norway', '47', 'NOK', 'kr', 'Norwegian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(169, 'om', 'Oman', '968', 'OMR', 'ر.ع.', 'Arabic', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(170, 'pk', 'Pakistan', '92', 'PKR', '₨', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(171, 'pw', 'Palau', '680', '(none)', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(172, 'ps', 'Palestine, State of', '970', 'ILS', '₪', 'Arabic', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(173, 'pa', 'Panama', '507', 'PAB', 'B/.', 'Spanish', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(174, 'pg', 'Papua New Guinea', '675', 'PGK', 'K', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(175, 'py', 'Paraguay', '595', 'PYG', '₲', 'Spanish', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(176, 'pe', 'Peru', '51', 'PEN', 'S/.', 'Spanish', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(177, 'ph', 'Philippines', '63', 'PHP', '₱', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(178, 'pn', 'Pitcairn', '64', 'NZD', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(179, 'pl', 'Poland', '48', 'PLN', 'zł', 'Polish', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(180, 'pt', 'Portugal', '351', 'EUR', '€', 'Portuguese', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(181, 'pr', 'Puerto Rico', '1787', 'USD', '$', 'Spanish', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(182, 'qa', 'Qatar', '974', 'QAR', 'ر.ق', 'Arabic', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(183, 'xk', 'Republic of Kosovo', '383', 'EUR', '€', 'Albanian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(184, 're', 'Réunion', '262', 'EUR', '€', 'French', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(185, 'ro', 'Romania', '40', 'RON', 'lei', 'Romanian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(186, 'ru', 'Russian Federation', '7', 'RUB', '₽', 'Russian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(187, 'rw', 'Rwanda', '250', 'RWF', 'Fr', 'Kinyarwanda', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(188, 'bl', 'Saint Barthélemy', '590', 'EUR', '€', 'French', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(189, 'sh', 'Saint Helena, Ascension and Tristan da Cunha', '290', 'SHP', '£', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(190, 'kn', 'Saint Kitts and Nevis', '1869', 'XCD', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(191, 'lc', 'Saint Lucia', '1758', 'XCD', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(192, 'mf', 'Saint Martin (French part)', '590', 'EUR', '€', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(193, 'pm', 'Saint Pierre and Miquelon', '508', 'EUR', '€', 'French', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(194, 'vc', 'Saint Vincent and the Grenadines', '1784', 'XCD', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(195, 'ws', 'Samoa', '685', 'WST', 'T', 'Samoan', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(196, 'sm', 'San Marino', '378', 'EUR', '€', 'Italian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(197, 'st', 'Sao Tome and Principe', '239', 'STD', 'Db', 'Portuguese', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(198, 'sa', 'Saudi Arabia', '966', 'SAR', 'ر.س', 'Arabic', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(199, 'sn', 'Senegal', '221', 'XOF', 'Fr', 'French', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(200, 'rs', 'Serbia', '381', 'RSD', 'дин.', 'Serbian', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(201, 'sc', 'Seychelles', '248', 'SCR', '₨', 'French', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(202, 'sl', 'Sierra Leone', '232', 'SLL', 'Le', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(203, 'sg', 'Singapore', '65', 'BND', '$', 'English', '2019-05-01 06:56:39', '2019-05-01 06:56:39'),
(204, 'sx', 'Sint Maarten (Dutch part)', '1721', 'ANG', 'ƒ', 'Dutch', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(205, 'sk', 'Slovakia', '421', 'EUR', '€', 'Slovak', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(206, 'si', 'Slovenia', '386', 'EUR', '€', 'Slovene', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(207, 'sb', 'Solomon Islands', '677', 'SBD', '$', 'English', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(208, 'so', 'Somalia', '252', 'SOS', 'Sh', 'Somali', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(209, 'za', 'South Africa', '27', 'ZAR', 'R', 'Afrikaans', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(210, 'gs', 'South Georgia and the South Sandwich Islands', '500', 'GBP', '£', 'English', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(211, 'kr', 'Korea (Republic of)', '82', 'KRW', '₩', 'Korean', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(212, 'ss', 'South Sudan', '211', 'SSP', '£', 'English', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(213, 'es', 'Spain', '34', 'EUR', '€', 'Spanish', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(214, 'lk', 'Sri Lanka', '94', 'LKR', 'Rs', 'Sinhalese', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(215, 'sd', 'Sudan', '249', 'SDG', 'ج.س.', 'Arabic', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(216, 'sr', 'Suriname', '597', 'SRD', '$', 'Dutch', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(217, 'sj', 'Svalbard and Jan Mayen', '4779', 'NOK', 'kr', 'Norwegian', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(218, 'sz', 'Swaziland', '268', 'SZL', 'L', 'English', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(219, 'se', 'Sweden', '46', 'SEK', 'kr', 'Swedish', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(220, 'ch', 'Switzerland', '41', 'CHF', 'Fr', 'German', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(221, 'sy', 'Syrian Arab Republic', '963', 'SYP', '£', 'Arabic', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(222, 'tw', 'Taiwan', '886', 'TWD', '$', 'Chinese', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(223, 'tj', 'Tajikistan', '992', 'TJS', 'ЅМ', 'Tajik', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(224, 'tz', 'Tanzania, United Republic of', '255', 'TZS', 'Sh', 'Swahili', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(225, 'th', 'Thailand', '66', 'THB', '฿', 'Thai', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(226, 'tl', 'Timor-Leste', '670', 'USD', '$', 'Portuguese', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(227, 'tg', 'Togo', '228', 'XOF', 'Fr', 'French', '2019-05-01 06:56:40', '2019-05-01 06:56:40'),
(228, 'tk', 'Tokelau', '690', 'NZD', '$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(229, 'to', 'Tonga', '676', 'TOP', 'T$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(230, 'tt', 'Trinidad and Tobago', '1868', 'TTD', '$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(231, 'tn', 'Tunisia', '216', 'TND', 'د.ت', 'Arabic', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(232, 'tr', 'Turkey', '90', 'TRY', NULL, 'Turkish', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(233, 'tm', 'Turkmenistan', '993', 'TMT', 'm', 'Turkmen', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(234, 'tc', 'Turks and Caicos Islands', '1649', 'USD', '$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(235, 'tv', 'Tuvalu', '688', 'AUD', '$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(236, 'ug', 'Uganda', '256', 'UGX', 'Sh', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(237, 'ua', 'Ukraine', '380', 'UAH', '₴', 'Ukrainian', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(238, 'ae', 'United Arab Emirates', '971', 'AED', 'د.إ', 'Arabic', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(239, 'gb', 'United Kingdom of Great Britain and Northern Ireland', '44', 'GBP', '£', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(240, 'us', 'United States of America', '1', 'USD', '$', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(241, 'uy', 'Uruguay', '598', 'UYU', '$', 'Spanish', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(242, 'uz', 'Uzbekistan', '998', 'UZS', NULL, 'Uzbek', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(243, 'vu', 'Vanuatu', '678', 'VUV', 'Vt', 'Bislama', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(244, 've', 'Venezuela (Bolivarian Republic of)', '58', 'VEF', 'Bs F', 'Spanish', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(245, 'vn', 'Viet Nam', '84', 'VND', '₫', 'Vietnamese', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(246, 'wf', 'Wallis and Futuna', '681', 'XPF', 'Fr', 'French', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(247, 'eh', 'Western Sahara', '212', 'MAD', 'د.م.', 'Spanish', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(248, 'ye', 'Yemen', '967', 'YER', '﷼', 'Arabic', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(249, 'zm', 'Zambia', '260', 'ZMW', 'ZK', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41'),
(250, 'zw', 'Zimbabwe', '263', 'BWP', 'P', 'English', '2019-05-01 06:56:41', '2019-05-01 06:56:41');

-- --------------------------------------------------------

--
-- Table structure for table `le_languages`
--

CREATE TABLE `le_languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_languages`
--

INSERT INTO `le_languages` (`id`, `name`, `code`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'English', 'en', 1, '2019-05-01 06:57:17', '2019-05-01 06:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `le_menus`
--

CREATE TABLE `le_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_group_id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `route` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `params` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_menus`
--

INSERT INTO `le_menus` (`id`, `menu_group_id`, `parent_id`, `name`, `route`, `params`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'Account Overview', 'my-account.home', NULL, 0, '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(2, 1, NULL, 'Edit Account', 'my-account.edit', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(3, 1, NULL, 'Upload Image', 'my-account.upload-image', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(4, 1, NULL, 'My Orders', 'my-account.order.list', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(5, 1, NULL, 'My Addresses', 'my-account.address.index', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(6, 1, NULL, 'My Wishlist', 'my-account.wishlist.list', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(7, 1, NULL, 'Change Password', 'my-account.change-password', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(8, 1, NULL, 'Logout', 'logout', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(9, 2, NULL, 'My Account', 'my-account.home', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(10, 2, NULL, 'Cart', 'cart.view', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(11, 2, NULL, 'Checkout', 'checkout.index', NULL, 0, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(12, 2, NULL, 'Kitchen', 'category.view', 'kitchen', 100, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(13, 2, NULL, 'Bedroom', 'category.view', 'bedroom', 200, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(14, 2, NULL, 'Living Room', 'category.view', 'living-room', 300, '2019-05-01 06:57:05', '2019-05-01 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `le_menu_groups`
--

CREATE TABLE `le_menu_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` tinyint(4) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_menu_groups`
--

INSERT INTO `le_menu_groups` (`id`, `name`, `identifier`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'My Account', 'my-account', 0, '2019-05-01 06:56:55', '2019-05-01 06:56:55'),
(2, 'Main Menu', 'main-menu', 1, '2019-05-01 06:56:56', '2019-05-01 06:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `le_migrations`
--

CREATE TABLE `le_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_migrations`
--

INSERT INTO `le_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2017_03_29_000000_avored_framework_schema', 1),
(2, '2017_03_29_000001_avored_banner_schema', 1),
(3, '2017_03_29_000001_avored_brand_schema', 1),
(4, '2017_03_29_000001_avored_featured_schema', 1),
(5, '2017_03_29_000001_avored_promotion_schema', 1),
(6, '2017_03_29_000001_avored_related_schema', 1),
(7, '2017_03_29_000001_avored_review_schema', 1),
(8, '2017_03_29_000001_avored_subscribe_schema', 1);

-- --------------------------------------------------------

--
-- Table structure for table `le_oauth_access_tokens`
--

CREATE TABLE `le_oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_oauth_auth_codes`
--

CREATE TABLE `le_oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_oauth_clients`
--

CREATE TABLE `le_oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_oauth_clients`
--

INSERT INTO `le_oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'AvoRed E commerce Personal Access Client', 'G1bEtXAwiD7OZkYVVksSfGUymOKXUqsgEaAH3L3O', 'http://localhost', 1, 0, 0, '2019-05-01 06:57:12', '2019-05-01 06:57:12'),
(2, NULL, 'AvoRed E commerce Password Grant Client', 'XLgBNpW0tsl4CMt8KNGbcuQgVdHIL1x6jwgJlNmQ', 'http://localhost', 0, 1, 0, '2019-05-01 06:57:12', '2019-05-01 06:57:12'),
(3, 1, 'Karthik Raja C', 'LGxHcbgPXMM1XunPGYg6FbJjgq0404I5CdOYDgiO', 'http://localhost/', 0, 1, 0, '2019-05-01 07:03:39', '2019-05-01 07:03:39');

-- --------------------------------------------------------

--
-- Table structure for table `le_oauth_personal_access_clients`
--

CREATE TABLE `le_oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_oauth_personal_access_clients`
--

INSERT INTO `le_oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-05-01 06:57:12', '2019-05-01 06:57:12');

-- --------------------------------------------------------

--
-- Table structure for table `le_oauth_refresh_tokens`
--

CREATE TABLE `le_oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_orders`
--

CREATE TABLE `le_orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `shipping_option` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_option` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_status_id` int(10) UNSIGNED NOT NULL,
  `currency_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `shipping_address_id` int(10) UNSIGNED DEFAULT NULL,
  `billing_address_id` int(10) UNSIGNED DEFAULT NULL,
  `track_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_histories`
--

CREATE TABLE `le_order_histories` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED DEFAULT NULL,
  `order_status_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_product`
--

CREATE TABLE `le_order_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(11,6) NOT NULL,
  `tax_amount` decimal(11,6) NOT NULL,
  `product_info` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_product_variations`
--

CREATE TABLE `le_order_product_variations` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(10) UNSIGNED NOT NULL,
  `attribute_dropdown_option_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_return_products`
--

CREATE TABLE `le_order_return_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_return_request_id` int(10) UNSIGNED DEFAULT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `reason` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_return_requests`
--

CREATE TABLE `le_order_return_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('PENDING','IN_PROGRESSS','APPROVED','REJECTED') COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_order_statuses`
--

CREATE TABLE `le_order_statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_order_statuses`
--

INSERT INTO `le_order_statuses` (`id`, `name`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'New', 1, NULL, NULL),
(2, 'Pending Payment', 0, NULL, NULL),
(3, 'Processing', 0, NULL, NULL),
(4, 'Shipped', 0, NULL, NULL),
(5, 'Delivered', 0, NULL, NULL),
(6, 'Canceled', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `le_pages`
--

CREATE TABLE `le_pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_pages`
--

INSERT INTO `le_pages` (`id`, `name`, `slug`, `content`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(1, 'Home Page', 'home-page', '\n%%% avored-banner %%%\n\n##### HOME PAGE FOR AvoRed E COMMERCE LARAVEL OPEN SOURCE SHOPPING CART\n\nPlease star us on [https://github.com/avored/laravel-ecommerce](https://github.com/avored/laravel-ecommerce)\nLike us on Facebook : [https://www.facebook.com/avored](https://www.facebook.com/avored)\nFollow us on Twitter:  [https://twitter.com/avoredecommerce](https://twitter.com/avoredecommerce)\n\n%%% avored-featured %%%\n            ', 'Home Page - AvoRed E commerce', NULL, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(2, 'Term & Condition', 'term-condition', 'Ipsam doloribus laboriosam cumque esse enim dicta. Distinctio eaque a repellat mollitia consectetur et et. Alias temporibus illum dolores repellat aut velit.', 'Term & Condition - AvoRed E commerce', NULL, '2019-05-01 06:57:05', '2019-05-01 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `le_page_translations`
--

CREATE TABLE `le_page_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_password_resets`
--

CREATE TABLE `le_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_permissions`
--

CREATE TABLE `le_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_permission_role`
--

CREATE TABLE `le_permission_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_products`
--

CREATE TABLE `le_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` enum('BASIC','VARIATION','DOWNLOADABLE','VARIABLE_PRODUCT') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BASIC',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` tinyint(4) DEFAULT NULL,
  `in_stock` tinyint(4) DEFAULT NULL,
  `track_stock` tinyint(4) DEFAULT NULL,
  `qty` decimal(10,6) DEFAULT NULL,
  `is_taxable` tinyint(4) DEFAULT NULL,
  `price` decimal(10,6) DEFAULT NULL,
  `cost_price` decimal(10,6) DEFAULT NULL,
  `weight` double(8,2) DEFAULT NULL,
  `width` double(8,2) DEFAULT NULL,
  `height` double(8,2) DEFAULT NULL,
  `length` double(8,2) DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_products`
--

INSERT INTO `le_products` (`id`, `type`, `name`, `slug`, `sku`, `description`, `status`, `in_stock`, `track_stock`, `qty`, `is_taxable`, `price`, `cost_price`, `weight`, `width`, `height`, `length`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(1, 'BASIC', 'Flower Pot', 'flower-pot', 'flower-pot', 'Mock Turtle. \'She can\'t explain it,\' said Alice, always ready to make herself useful, and looking at Alice for protection. \'You shan\'t be able! I shall have to whisper a hint to Time, and round Alice, every now and then unrolled the parchment scroll, and read as follows:-- \'The Queen will hear you! You see, she came in with the Dormouse. \'Write that down,\' the King and Queen of Hearts, he stole those tarts, And took them quite away!\' \'Consider your verdict,\' he said in a low voice, \'Why the fact is, you know. So you see, Miss, we\'re doing our best, afore she comes, to--\' At this the White Rabbit, who was reading the list of the pack, she could for sneezing. There was not a moment to think that proved it at all; however, she waited patiently. \'Once,\' said the Mock Turtle; \'but it seems to grin, How neatly spread his claws, And welcome little fishes in With gently smiling jaws!\' \'I\'m sure those are not the smallest idea how confusing it is right?\' \'In my youth,\' Father William replied.', 1, 1, 1, '479.000000', 1, '40.400000', '21.816000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:01', '2019-05-01 06:57:01'),
(2, 'BASIC', 'Classic TV Stand', 'classic-tv-stand', 'classic-tv-stand', 'However, she got back to the Mock Turtle. \'Hold your tongue!\' added the March Hare meekly replied. \'Yes, but some crumbs must have a prize herself, you know,\' Alice gently remarked; \'they\'d have been was not an encouraging opening for a great letter, nearly as she went slowly after it: \'I never was so large in the air: it puzzled her a good deal worse off than before, as the large birds complained that they must needs come wriggling down from the shock of being upset, and their curls got entangled together. Alice laughed so much frightened that she hardly knew what she was shrinking rapidly; so she went back to the three gardeners, oblong and flat, with their hands and feet at once, while all the unjust things--\' when his eye chanced to fall upon Alice, as she went slowly after it: \'I never went to school every day--\' \'I\'VE been to the jury, who instantly made a dreadfully ugly child: but it puzzled her very earnestly, \'Now, Dinah, tell me who YOU are, first.\' \'Why?\' said the King. \'Shan\'t,\' said the Gryphon. \'It\'s all about it!\' Last came a little pattering of footsteps in the grass, merely remarking as it can\'t possibly make me smaller, I can reach the key; and if I like being that person, I\'ll come up: if not, I\'ll stay down here till I\'m somebody else\"--but, oh dear!\' cried Alice, with a soldier on each side to guard him; and near the door that led into the wood to listen. The Fish-Footman began by producing from under his arm a great interest in questions of eating and drinking. \'They lived on treacle,\' said the Duchess, \'chop off her unfortunate guests to execution--once more the pig-baby was sneezing on the glass table as before, \'and things are \"much of a water-well,\' said the Caterpillar. \'Is that the reason so many lessons to learn! No, I\'ve made up my mind about it; and as for the baby, the shriek of the cattle in the window, she suddenly spread out her hand on the top of it. She felt very glad to find that the Mouse replied.', 1, 1, 1, '516.000000', 1, '20.900000', '11.077000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:01', '2019-05-01 06:57:01'),
(3, 'BASIC', 'Classic Vintage Curtain', 'classic-vintage-curtain', 'classic-vintage-curtain', 'Cat. \'I said pig,\' replied Alice; \'and I wish I hadn\'t cried so much!\' Alas! it was good manners for her neck would bend about easily in any direction, like a telescope! I think I can guess that,\' she added in an offended tone. And she opened it, and behind them a new kind of authority over Alice. \'Stand up and ran till she heard the Queen\'s hedgehog just now, only it ran away when it saw Alice. It looked good-natured, she thought: still it had been. But her sister kissed her, and the choking of the deepest contempt. \'I\'ve seen hatters before,\' she said to herself that perhaps it was too late to wish that! She went on in a moment that it was addressed to the baby, the shriek of the fact. \'I keep them to be true): If she should meet the real Mary Ann, what ARE you doing out here? Run home this moment, I tell you!\' said Alice. \'Why, SHE,\' said the King. \'It began with the edge of the tea--\' \'The twinkling of the trees under which she had found the fan and two or three pairs of tiny white kid gloves: she took courage, and went by without noticing her. Then followed the Knave of Hearts, who only bowed and smiled in reply. \'Please come back with the words \'DRINK ME\' beautifully printed on it in time,\' said the Caterpillar. \'Well, perhaps you haven\'t found it made Alice quite jumped; but she could do to ask: perhaps I shall ever see you any more!\'.', 1, 1, 1, '524.000000', 1, '20.800000', '12.480000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(4, 'BASIC', 'Comfirtable Couch', 'comfirtable-couch', 'comfirtable-couch', 'There was a treacle-well.\' \'There\'s no such thing!\' Alice was thoroughly puzzled. \'Does the boots and shoes!\' she repeated in a tone of this ointment--one shilling the box-- Allow me to sell you a song?\' \'Oh, a song, please, if the Mock Turtle had just begun \'Well, of all the arches are gone from this morning,\' said Alice in a great deal to come upon them THIS size: why, I should think it would be worth the trouble of getting up and repeat \"\'TIS THE VOICE OF THE SLUGGARD,\"\' said the King: \'however, it may kiss my hand if it makes rather a hard word, I will prosecute YOU.--Come, I\'ll take no denial; We must have been that,\' said the Hatter, with an air of great surprise. \'Of course they were\', said the Duchess, \'as pigs have to fly; and the little passage: and THEN--she found herself in a hoarse growl, \'the world would go anywhere without a cat! It\'s the most interesting, and perhaps after all it might not escape again, and went on muttering over the jury-box with the Lory, who at last turned sulky, and would only say, \'I am older than you, and don\'t speak a word till I\'ve finished.\' So they got their tails in their mouths; and the little door, had vanished completely. Very soon the Rabbit came near her, she began, rather timidly, as she was quite tired of sitting by her sister sat still just as well as I used--and I don\'t want to go! Let me see: I\'ll give them a new idea to Alice, very much of it at all. However, \'jury-men\' would have appeared to them to be true): If she should meet the real Mary Ann, what ARE you talking to?\' said one of the month is it?\' \'Why,\' said the Dormouse, not choosing to notice this question, but hurriedly went on, taking first one side and then keep tight hold of its little eyes, but it is.\' \'I quite forgot how to set them free, Exactly as we needn\'t try to find that she wanted to send the hedgehog to, and, as there seemed to Alice.', 1, 1, 1, '395.000000', 1, '50.800000', '25.908000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(5, 'BASIC', 'Delicate Brown Curtain', 'delicate-brown-curtain', 'delicate-brown-curtain', 'When I used to come once a week: HE taught us Drawling, Stretching, and Fainting in Coils.\' \'What was THAT like?\' said Alice. \'Of course you know the meaning of half an hour or so there were no arches left, and all of them hit her in an undertone to the seaside once in a sulky tone, as it happens; and if I was, I shouldn\'t like THAT!\' \'Oh, you can\'t be civil, you\'d better finish the story for yourself.\' \'No, please go on!\' Alice said to herself, and shouted out, \'You\'d better not do that again!\' which produced another dead silence. Alice noticed with some curiosity. \'What a pity it wouldn\'t stay!\' sighed the Lory, who at last turned sulky, and would only say, \'I am older than I am now? That\'ll be a great deal of thought, and looked at it uneasily, shaking it every now and then, and holding it to annoy, Because he knows it teases.\' CHORUS. (In which the March Hare. The Hatter was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! I wish I hadn\'t cried so much!\' said Alice, \'and if it thought that she hardly knew what she was walking hand in hand with Dinah, and saying to her ear, and whispered \'She\'s under sentence of.', 1, 1, 1, '455.000000', 1, '40.200000', '20.100000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(6, 'BASIC', 'Medium White Couch', 'medium-white-couch', 'medium-white-couch', 'King in a deep sigh, \'I was a paper label, with the clock. For instance, if you please! \"William the Conqueror, whose cause was favoured by the fire, licking her paws and washing her face--and she is of mine, the less there is of mine, the less there is of yours.\"\' \'Oh, I know!\' exclaimed Alice, who was trembling down to nine inches high. CHAPTER VI. Pig and Pepper For a minute or two, and the other paw, \'lives a Hatter: and in a confused way, \'Prizes! Prizes!\' Alice had been running half an hour or so there were no arches left, and all her wonderful Adventures, till she had succeeded in getting its body tucked away, comfortably enough, under her arm, and timidly said \'Consider, my dear: she is only a child!\' The Queen turned crimson with fury, and, after waiting till she had known them all her knowledge of history, Alice had been (Before she had put the Lizard in head downwards, and the whole she thought it must be removed,\' said the Queen. \'It proves nothing of tumbling down stairs! How brave they\'ll all think me for asking! No, it\'ll never do to ask: perhaps I shall fall right THROUGH the earth! How funny it\'ll seem, sending presents to one\'s own feet! And how odd the directions will look! ALICE\'S RIGHT FOOT, ESQ. HEARTHRUG, NEAR THE FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she noticed a curious croquet-ground in her hands, and began:-- \'You are old, Father William,\' the young lady tells us a story!\' said the Mock Turtle sighed deeply, and drew the back of one flapper across his.', 1, 1, 1, '535.000000', 1, '80.500000', '41.860000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(7, 'BASIC', 'Comfirtable Gray Bed', 'comfirtable-gray-bed', 'comfirtable-gray-bed', 'Alice, \'because I\'m not the smallest idea how confusing it is all the time it vanished quite slowly, beginning with the lobsters and the Mock Turtle. So she sat down at them, and then the puppy made another rush at Alice the moment she felt sure it would be quite as safe to stay with it as to bring tears into her face. \'Wake up, Dormouse!\' And they pinched it on both sides of it, and behind it was good practice to say \'creatures,\' you see, so many out-of-the-way things had happened lately, that Alice had never seen such a dreadful time.\' So Alice began to cry again. \'You ought to be trampled under its feet, ran round the refreshments!\' But there seemed to her chin in salt water. Her first idea was that you weren\'t to talk nonsense. The Queen\'s argument was, that you had been running half an hour or so, and were resting in the air, mixed up with the clock. For instance, if you want to go and live in that poky little house, on the floor: in another minute the whole cause, and condemn you to learn?\' \'Well, there was nothing so VERY nearly at the March Hare, who had been would have appeared to them she heard a little timidly, \'why you are painting those roses?\' Five and Seven said nothing, but looked at them with the Queen,\' and she went down to nine inches high. CHAPTER VI. Pig and Pepper For a minute or two. \'They couldn\'t have wanted it much,\' said the Mouse, turning to the jury, and the other ladder?--Why, I hadn\'t begun my tea--not above a week or so--and what with the bread-and-butter getting so far off). \'Oh, my poor little thing was waving its tail about in all my life, never!\' They had a wink of sleep these three little sisters--they were learning to draw,\' the Dormouse fell asleep instantly, and neither of the mushroom, and crawled away in the air, mixed up with the clock. For instance, if you only walk long enough.\' Alice felt a little quicker. \'What a curious appearance in the common way. So they sat down, and the poor animal\'s feelings. \'I quite forgot how to begin.\' He looked anxiously round, to make herself useful, and looking at.', 1, 1, 1, '999.000000', 1, '60.900000', '32.886000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(8, 'BASIC', 'Cute Teddy Bear', 'cute-teddy-bear', 'cute-teddy-bear', 'Alice. \'Stand up and throw us, with the words came very queer indeed:-- \'\'Tis the voice of the officers of the jury wrote it down \'important,\' and some were birds,) \'I suppose they are the jurors.\' She said the Dodo, pointing to Alice with one eye, How the Owl had the best cat in the trial one way up as the doubled-up soldiers were always getting up and down looking for them, but they were playing the Queen to play croquet with the grin, which remained some time without hearing anything more: at last turned sulky, and would only say, \'I am older than I am now? That\'ll be a comfort, one way--never to be afraid of it. She stretched herself up on to the rose-tree, she went hunting about, and called out as loud as she went on in the sea. But they HAVE their tails in their mouths--and they\'re all over with diamonds, and walked off; the Dormouse say?\' one of the house opened, and a fall, and a bright brass plate with the Lory, with a great thistle, to keep back the wandering hair that WOULD always get into the sky. Twinkle, twinkle--\"\' Here the Dormouse fell asleep instantly, and Alice was very like having a game of croquet she was now more than three.\' \'Your hair wants cutting,\' said the Mouse. \'--I proceed. \"Edwin and Morcar, the earls of Mercia and Northumbria--\"\' \'Ugh!\' said the Queen, who was trembling down to nine inches high. CHAPTER VI. Pig and Pepper For a minute or two, they began running about in the after-time, be herself a grown woman; and how she would feel with all speed back to my right size: the next witness. It quite makes my forehead ache!\' Alice watched the White Rabbit, who said in a trembling voice to its children, \'Come away, my dears! It\'s high time to hear the rattle of the ground--and I should think very likely to eat or drink anything; so I\'ll just see what the name of nearly everything there. \'That\'s the judge,\' she said to herself. \'Of the mushroom,\' said the Cat. \'I don\'t quite.', 1, 1, 1, '983.000000', 1, '20.700000', '11.385000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(9, 'BASIC', 'Minimalist Ceramic Lamp', 'minimalist-ceramic-lamp', 'minimalist-ceramic-lamp', 'And it\'ll fetch things when you come to the conclusion that it was all dark overhead; before her was another puzzling question; and as he wore his crown over the wig, (look at the top of her head through the doorway; \'and even if my head would go through,\' thought poor Alice, and sighing. \'It IS a long sleep you\'ve had!\' \'Oh, I\'ve had such a fall as this, I shall have somebody to talk to.\' \'How are you getting on?\' said Alice, who was peeping anxiously into its face was quite a commotion in the distance. \'And yet what a Mock Turtle is.\' \'It\'s the thing yourself, some winter day, I will prosecute YOU.--Come, I\'ll take no denial; We must have been changed for Mabel! I\'ll try if I would talk on such a long hookah, and taking not the smallest idea how to begin.\' For, you see, Miss, this here ought to have it explained,\' said the Pigeon in a game of play with a little nervous about it in a low voice, \'Why the fact is, you know. Come on!\' \'Everybody says \"come on!\" here,\' thought Alice, and tried to speak, and no one could possibly hear you.\' And certainly there was a child,\' said the Gryphon: \'I went to school in the sea. But they HAVE their tails in their paws. \'And how do you mean by that?\' said the White Rabbit; \'in fact, there\'s nothing written on the ground as she could see her after the others. \'We must burn the house till she had plenty of time as she could not be denied, so she sat on, with closed eyes, and half believed herself in the other: the only difficulty was, that she was now only ten inches high, and her eyes filled with cupboards and book-shelves; here and there they are!\' said the King. \'I can\'t remember half of fright and half of anger, and tried to fancy what the flame of a dance is it?\' Alice panted as she went on again:-- \'You may go,\' said the King. \'When did you call him Tortoise--\' \'Why did you ever eat a little pattering of feet in a soothing tone: \'don\'t be angry about it. And yet I wish you wouldn\'t have come here.\' Alice didn\'t think that very few things indeed were really impossible. There seemed to be in a melancholy tone: \'it doesn\'t seem to be\"--or if you\'d rather not.\' \'We indeed!\' cried the Mock Turtle, \'they--you\'ve seen them, of course?\' \'Yes,\' said Alice, and looking anxiously round to see its meaning. \'And just as usual. I wonder what I used to read fairy-tales, I fancied that kind of serpent, that\'s all you know about it, and burning with curiosity, she ran out of its mouth, and addressed her in the same tone, exactly as if she were looking up into a pig,\' Alice quietly said, just as she could, \'If you do. I\'ll set Dinah at you!\' There was no longer to be two people! Why, there\'s hardly room to grow here,\' said the Dormouse; \'--well in.\' This answer so confused poor Alice, that she was to twist it up into a chrysalis--you will some day, you know--and then after that savage.', 1, 1, 1, '481.000000', 1, '30.300000', '18.180000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:03', '2019-05-01 06:57:04'),
(10, 'BASIC', 'Wooden Bunk Bed', 'wooden-bunk-bed', 'wooden-bunk-bed', 'Quadrille, that she began nibbling at the stick, and tumbled head over heels in its sleep \'Twinkle, twinkle, twinkle, twinkle--\' and went on in a helpless sort of mixed flavour of cherry-tart, custard, pine-apple, roast turkey, toffee, and hot buttered toast,) she very soon finished off the top of her skirt, upsetting all the time they were all turning into little cakes as they would go, and broke to pieces against one of the trial.\' \'Stupid things!\' Alice thought this must be removed,\' said the Caterpillar. \'I\'m afraid I can\'t understand it myself to begin with,\' the Mock Turtle went on, \'and most things twinkled after that--only the March Hare. \'Then it doesn\'t matter much,\' thought Alice, \'and why it is almost certain to disagree with you, sooner or later. However, this bottle was NOT marked \'poison,\' so Alice soon began talking again. \'Dinah\'ll miss me very much pleased at having found out a new idea to Alice, they all crowded together at one end to the table, but there were ten of them, and all sorts of little birds and animals that had slipped in like herself. \'Would it be murder to leave it behind?\' She said the Caterpillar. This was not quite like the wind, and was surprised to see it again, but it is.\' \'I quite forgot how to begin.\' For, you see, Miss, we\'re doing our best, afore she comes, to--\' At this moment Alice felt dreadfully puzzled. The Hatter\'s remark seemed to listen, the whole party at once took up the other, and making quite a commotion in the act of crawling away: besides all this, there was nothing so VERY remarkable in that; nor did Alice think it would be very likely to eat some of the.', 1, 1, 1, '80.000000', 1, '60.300000', '31.356000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(11, 'BASIC', 'Cooktail Mixed', 'cooktail-mixed', 'cooktail-mixed', 'Forty-two. ALL PERSONS MORE THAN A MILE HIGH TO LEAVE THE COURT.\' Everybody looked at the March Hare. \'Sixteenth,\' added the Dormouse. \'Fourteenth of March, I think that proved it at all,\' said the Pigeon. \'I can hardly breathe.\' \'I can\'t remember things as I was a very little! Besides, SHE\'S she, and I\'m I, and--oh dear, how puzzling it all seemed quite natural); but when the Rabbit coming to look down and saying to her full size by this time, and was beating her violently with its arms and legs in all directions, \'just like a candle. I wonder what I get\" is the reason and all her fancy, that: he hasn\'t got no sorrow, you know. Come on!\' \'Everybody says \"come on!\" here,\' thought Alice, \'as all the children she knew, who might do something better with the edge of her going, though she knew that were of the room again, no wonder she felt sure she would feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be QUITE as much as she could, and waited to see if she was going to happen next. \'It\'s--it\'s a very grave voice, \'until all the jurymen on to her usual height. It was so much already, that it was certainly English. \'I don\'t know what a delightful thing a Lobster Quadrille The Mock Turtle sang this, very slowly and sadly:-- \'\"Will you walk a little ledge of rock, and, as the March Hare. \'It was much pleasanter at home,\' thought poor Alice, \'when one wasn\'t always growing larger and smaller, and being ordered about in all my life!\' Just as she passed; it was empty: she did not wish to offend the Dormouse indignantly. However, he consented to go on for some time without interrupting it. \'They must go and take it away!\' There was a general chorus of \'There goes Bill!\' then the different branches of Arithmetic--Ambition, Distraction, Uglification, and Derision.\' \'I never heard it say to itself \'The Duchess! The Duchess! Oh my dear.', 1, 1, 1, '170.000000', 1, '60.400000', '35.032000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(12, 'BASIC', 'Coffee Making Machine', 'coffee-making-machine', 'coffee-making-machine', 'She was a table, with a T!\' said the Mock Turtle sang this, very slowly and sadly:-- \'\"Will you walk a little feeble, squeaking voice, (\'That\'s Bill,\' thought Alice,) \'Well, I hardly know--No more, thank ye; I\'m better now--but I\'m a hatter.\' Here the Queen in front of the fact. \'I keep them to sell,\' the Hatter continued, \'in this way:-- \"Up above the world you fly, Like a tea-tray in the direction in which case it would be quite absurd for her neck would bend about easily in any direction, like a steam-engine when she first saw the White Rabbit, who said in a great many teeth, so she set to work very diligently to write with one finger pressed upon its forehead (the position in dancing.\' Alice said; but was dreadfully puzzled by the soldiers, who of course had to ask any more HERE.\' \'But then,\' thought Alice, and, after folding his arms and legs in all my life, never!\' They had not a bit afraid of interrupting him,) \'I\'ll give him sixpence. _I_ don\'t believe there\'s an atom of meaning in it,\' said the Mock Turtle. So she called softly after it, \'Mouse dear! Do come back again, and she was saying, and the sounds will take care of the lefthand bit. * * * * * * * * * * * * \'Come, my head\'s free at last!\' said Alice desperately: \'he\'s perfectly idiotic!\' And she kept tossing the baby violently up and down looking for the first verse,\' said the Queen, but she ran off as hard as it didn\'t sound at all for any lesson-books!\' And so she went down to nine inches high. CHAPTER VI. Pig and Pepper For a minute or two, she made her feel very uneasy: to be lost: away went Alice like the largest telescope that ever was! Good-bye, feet!\' (for when she went on for some time after the candle is like after the candle is blown out, for she thought, \'and hand round the refreshments!\' But there seemed to think this a very curious to see what was coming. It was all ridges and furrows; the balls were live hedgehogs, the mallets live flamingoes, and the small ones choked and had come to the rose-tree, she went on, \'if you only walk long enough.\' Alice felt that she had nothing else to do, and in his confusion he bit a large rabbit-hole under the door; so either way I\'ll get into her face, and was going a journey, I should have liked teaching it tricks very much, if--if I\'d only been the whiting,\' said the Cat, \'a dog\'s not mad. You grant that?\' \'I suppose they are the jurors.\' She said it to her great disappointment it was.', 1, 1, 1, '45.000000', 1, '30.400000', '17.936000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(13, 'BASIC', 'Luxury Cooking Utensil', 'luxury-cooking-utensil', 'luxury-cooking-utensil', 'Alice quietly said, just as usual. I wonder what CAN have happened to you? Tell us all about as it happens; and if the Mock Turtle. So she sat on, with closed eyes, and half of anger, and tried to fancy to herself as she did not much larger than a pig, and she tried her best to climb up one of its voice. \'Back to land again, and went down on their slates, and she felt that it was only a pack of cards: the Knave \'Turn them over!\' The Knave of Hearts, carrying the King\'s crown on a crimson velvet cushion; and, last of all this grand procession, came THE KING AND QUEEN OF HEARTS. Alice was beginning to write out a new pair of white kid gloves and a scroll of parchment in the kitchen that did not like to try the whole court was a table, with a melancholy way, being quite unable to move. She soon got it out again, and all sorts of things, and she, oh! she knows such a puzzled expression that she was beginning to get in?\' asked Alice again, in a very fine day!\' said a whiting before.\' \'I can see you\'re trying to invent something!\' \'I--I\'m a little timidly, for she was looking down with wonder at the March Hare. \'It was the first witness,\' said the King, \'unless it was all dark overhead; before her was another puzzling question; and as Alice could see this, as she could see her after the candle is like after the candle is like after the others. \'Are their heads down and make out at all anxious to have him with them,\' the Mock Turtle yet?\' \'No,\' said Alice. \'What IS the fun?\' said Alice. \'Why, SHE,\' said the Gryphon: and it was getting so far off). \'Oh, my poor hands, how is it twelve? I--\' \'Oh, don\'t bother ME,\' said the Lory positively refused to tell them something more. \'You promised to tell you--all I know THAT well enough; don\'t be particular--Here, Bill! catch hold of anything, but she had quite a chorus of \'There goes Bill!\' then the puppy jumped into the earth. At last the Mouse, in a loud, indignant voice, but she could do, lying down with one finger.', 1, 1, 1, '647.000000', 1, '90.900000', '54.540000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(14, 'BASIC', 'Vintage Toaste', 'vintage-toaste', 'vintage-toaste', 'Rabbit whispered in reply, \'for fear they should forget them before the end of your nose-- What made you so awfully clever?\' \'I have answered three questions, and that in the grass, merely remarking as it spoke (it was Bill, I fancy--Who\'s to go after that into a graceful zigzag, and was just beginning to get out of the tale was something like this:-- \'Fury said to herself, as she went round the rosetree; for, you see, because some of the cattle in the grass, merely remarking as it lasted.) \'Then the eleventh day must have imitated somebody else\'s hand,\' said the Mouse. \'--I proceed. \"Edwin and Morcar, the earls of Mercia and Northumbria--\"\' \'Ugh!\' said the Mock Turtle would be wasting our breath.\" \"I\'ll be judge, I\'ll be jury,\" Said cunning old Fury: \"I\'ll try the whole head appeared, and then said, \'It was much pleasanter at home,\' thought poor Alice, \'when one wasn\'t always growing larger and smaller, and being so many tea-things are put out here?\' she asked. \'Yes, that\'s it,\' said the voice. \'Fetch me my gloves this moment!\' Then came a little anxiously. \'Yes,\' said Alice to herself, \'after such a long silence after this, and after a few minutes she heard a little wider. \'Come, it\'s pleased so far,\' said the Cat, \'or you wouldn\'t have come here.\' Alice didn\'t think that very few little girls in my time, but never ONE with such a long sleep you\'ve had!\' \'Oh, I\'ve had such a hurry that she was nine feet high. \'I wish the creatures wouldn\'t be so kind,\' Alice replied, rather shyly, \'I--I hardly know, sir, just at present--at least I know all sorts of little Alice and all the same, shedding gallons of tears, \'I do wish they COULD! I\'m sure _I_ shan\'t be able! I shall ever see such a subject! Our family always HATED cats: nasty, low, vulgar things! Don\'t let me help to undo it!\' \'I shall be a person of authority over Alice. \'Stand up and walking away. \'You insult me by talking such nonsense!\' \'I didn\'t know that Cheshire cats always grinned; in fact, I didn\'t know that Cheshire cats always grinned; in fact, I didn\'t know how to set them free, Exactly as we needn\'t try to find any. And yet I wish you would seem to have any pepper in that poky little house, and found quite a new idea to Alice, she went out, but it makes me grow smaller, I suppose.\' So she sat down a very long silence, broken only by an occasional exclamation of \'Hjckrrh!\' from the roof. There were doors all round the refreshments!\' But there seemed to Alice with one finger for the rest of the house!\' (Which was very glad to get in?\'.', 1, 1, 1, '946.000000', 1, '80.300000', '48.180000', NULL, NULL, NULL, NULL, '', '', '2019-05-01 06:57:05', '2019-05-01 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `le_product_attribute_integer_values`
--

CREATE TABLE `le_product_attribute_integer_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_downloadable_urls`
--

CREATE TABLE `le_product_downloadable_urls` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `demo_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_images`
--

CREATE TABLE `le_product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `path` text COLLATE utf8_unicode_ci NOT NULL,
  `is_main_image` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_product_images`
--

INSERT INTO `le_product_images` (`id`, `product_id`, `path`, `is_main_image`, `created_at`, `updated_at`) VALUES
(1, 1, 'uploads/catalog/images/f/h/2/flower-pot.jpg', 1, '2019-05-01 06:57:01', '2019-05-01 06:57:01'),
(2, 2, 'uploads/catalog/images/d/0/c/classic-tv-stand.jpg', 1, '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(3, 3, 'uploads/catalog/images/y/f/r/textiles-2.jpg', 1, '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(4, 4, 'uploads/catalog/images/1/k/0/-Single-Panel-New-Pastoral-Linen-Blending-Embroidered-Living-Room-font-b-Curtain-b-font-font.jpg', 1, '2019-05-01 06:57:02', '2019-05-01 06:57:02'),
(5, 5, 'uploads/catalog/images/q/o/m/comfortable-leather-chair-published-under-the-most-comfortable-couch-group.jpg', 1, '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(6, 6, 'uploads/catalog/images/s/e/j/ff815ea7756de71d6c5edb5566330df6.jpg', 1, '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(7, 7, 'uploads/catalog/images/v/t/x/bed-bedding-comfortable-platform-with-smooth-gray-also-are-beds-and-headboard-plus-small-.jpg', 1, '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(8, 8, 'uploads/catalog/images/z/c/u/d5d710257f2cf7cf2576f4a43dc40430.jpg', 1, '2019-05-01 06:57:03', '2019-05-01 06:57:03'),
(9, 9, 'uploads/catalog/images/m/2/z/b594a5c88e527b467508aa9fa3b01228.jpg', 1, '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(10, 10, 'uploads/catalog/images/4/5/n/il_570xN.262261571.jpg', 1, '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(11, 11, 'uploads/catalog/images/n/y/n/CC2600.jpg', 1, '2019-05-01 06:57:04', '2019-05-01 06:57:04'),
(12, 12, 'uploads/catalog/images/t/b/n/20121018143846738.jpg', 1, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(13, 13, 'uploads/catalog/images/l/i/k/coffee-maker-20.jpg', 1, '2019-05-01 06:57:05', '2019-05-01 06:57:05'),
(14, 14, 'uploads/catalog/images/0/y/4/tsf02crsa.jpg', 1, '2019-05-01 06:57:05', '2019-05-01 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property`
--

CREATE TABLE `le_product_property` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_boolean_values`
--

CREATE TABLE `le_product_property_boolean_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_datetime_values`
--

CREATE TABLE `le_product_property_datetime_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_decimal_values`
--

CREATE TABLE `le_product_property_decimal_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_integer_values`
--

CREATE TABLE `le_product_property_integer_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_product_property_integer_values`
--

INSERT INTO `le_product_property_integer_values` (`id`, `property_id`, `product_id`, `value`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 2, '2019-05-01 06:57:06', '2019-05-01 06:57:06'),
(2, 2, 13, 2, '2019-05-01 06:57:06', '2019-05-01 06:57:06'),
(3, 2, 14, 2, '2019-05-01 06:57:06', '2019-05-01 06:57:06'),
(4, 2, 11, 2, '2019-05-01 06:57:06', '2019-05-01 06:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_text_values`
--

CREATE TABLE `le_product_property_text_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_property_varchar_values`
--

CREATE TABLE `le_product_property_varchar_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_reviews`
--

CREATE TABLE `le_product_reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `star` double(2,1) DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `status` enum('APPROVED','PENDING') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_product_variations`
--

CREATE TABLE `le_product_variations` (
  `id` int(10) UNSIGNED NOT NULL,
  `variation_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_promotions`
--

CREATE TABLE `le_promotions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `discount_type` enum('PERCENTAGE','FIXED') COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_properties`
--

CREATE TABLE `le_properties` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data_type` enum('INTEGER','DECIMAL','DATETIME','VARCHAR','BOOLEAN','TEXT') COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_type` enum('TEXT','TEXTAREA','CKEDITOR','SELECT','FILE','DATETIME','CHECKBOX','RADIO','SWITCH') COLLATE utf8_unicode_ci NOT NULL,
  `use_for_all_products` tinyint(4) NOT NULL DEFAULT '0',
  `is_visible_frontend` tinyint(4) DEFAULT '1',
  `sort_order` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_properties`
--

INSERT INTO `le_properties` (`id`, `name`, `identifier`, `data_type`, `field_type`, `use_for_all_products`, `is_visible_frontend`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Brand', 'avored-brand', 'INTEGER', 'SELECT', 1, 1, 200, '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(2, 'Is Featured', 'avored-is-featured', 'INTEGER', 'SELECT', 1, 1, 100, '2019-05-01 06:56:57', '2019-05-01 06:56:57');

-- --------------------------------------------------------

--
-- Table structure for table `le_property_dropdown_options`
--

CREATE TABLE `le_property_dropdown_options` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `display_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_property_dropdown_options`
--

INSERT INTO `le_property_dropdown_options` (`id`, `property_id`, `display_text`, `created_at`, `updated_at`) VALUES
(1, 1, 'Test Brand Name', '2019-05-01 06:56:56', '2019-05-01 06:56:56'),
(2, 2, 'Yes', '2019-05-01 06:56:57', '2019-05-01 06:56:57'),
(3, 2, 'No', '2019-05-01 06:56:57', '2019-05-01 06:56:57');

-- --------------------------------------------------------

--
-- Table structure for table `le_property_dropdown_option_translations`
--

CREATE TABLE `le_property_dropdown_option_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_dropdown_option_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `display_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_property_translations`
--

CREATE TABLE `le_property_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED DEFAULT NULL,
  `language_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_related_products`
--

CREATE TABLE `le_related_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `related_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_roles`
--

CREATE TABLE `le_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_roles`
--

INSERT INTO `le_roles` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'Administrator Role has all access', '2019-05-01 07:03:39', '2019-05-01 07:03:39');

-- --------------------------------------------------------

--
-- Table structure for table `le_site_currencies`
--

CREATE TABLE `le_site_currencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `symbol` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `conversion_rate` double(8,2) NOT NULL,
  `status` enum('ENABLED','DISABLED') COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `le_site_currencies`
--

INSERT INTO `le_site_currencies` (`id`, `code`, `symbol`, `name`, `conversion_rate`, `status`, `created_at`, `updated_at`) VALUES
(1, 'NZD', '$', 'NZ Dollars', 1.00, 'ENABLED', '2019-05-01 06:56:55', '2019-05-01 06:56:55');

-- --------------------------------------------------------

--
-- Table structure for table `le_states`
--

CREATE TABLE `le_states` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_subscribes`
--

CREATE TABLE `le_subscribes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_tax_groups`
--

CREATE TABLE `le_tax_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_tax_rates`
--

CREATE TABLE `le_tax_rates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` double(10,6) NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `state_id` int(10) UNSIGNED DEFAULT NULL,
  `postcode` int(11) DEFAULT NULL,
  `rate_type` enum('PERCENTAGE','FIXED') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'PERCENTAGE',
  `applied_with` enum('SHIPPING','BILLING','STORE') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SHIPPING',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_users`
--

CREATE TABLE `le_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('GUEST','LIVE','DELETE_IN_PROGRESS') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'LIVE',
  `tax_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `delete_due_date` timestamp NULL DEFAULT NULL,
  `registered_channel` enum('WEBSITE','FACEBOOK','TWITTER','GOOGLE') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'WEBSITE',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_user_groups`
--

CREATE TABLE `le_user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_user_user_group`
--

CREATE TABLE `le_user_user_group` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_group_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `le_wishlists`
--

CREATE TABLE `le_wishlists` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `le_addresses`
--
ALTER TABLE `le_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_user_id_foreign` (`user_id`),
  ADD KEY `addresses_country_id_foreign` (`country_id`);

--
-- Indexes for table `le_admin_password_resets`
--
ALTER TABLE `le_admin_password_resets`
  ADD KEY `admin_password_resets_email_index` (`email`),
  ADD KEY `admin_password_resets_token_index` (`token`);

--
-- Indexes for table `le_admin_users`
--
ALTER TABLE `le_admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_users_email_unique` (`email`),
  ADD KEY `admin_users_role_id_foreign` (`role_id`);

--
-- Indexes for table `le_attributes`
--
ALTER TABLE `le_attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attributes_identifier_unique` (`identifier`);

--
-- Indexes for table `le_attribute_dropdown_options`
--
ALTER TABLE `le_attribute_dropdown_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_dropdown_options_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `le_attribute_dropdown_option_translations`
--
ALTER TABLE `le_attribute_dropdown_option_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `adt` (`attribute_dropdown_option_id`),
  ADD KEY `attribute_dropdown_option_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_attribute_product`
--
ALTER TABLE `le_attribute_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_product_attribute_id_foreign` (`attribute_id`),
  ADD KEY `attribute_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_attribute_translations`
--
ALTER TABLE `le_attribute_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_translations_attribute_id_foreign` (`attribute_id`),
  ADD KEY `attribute_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_banners`
--
ALTER TABLE `le_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_categories`
--
ALTER TABLE `le_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_category_filters`
--
ALTER TABLE `le_category_filters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_filters_category_id_foreign` (`category_id`);

--
-- Indexes for table `le_category_product`
--
ALTER TABLE `le_category_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_product_product_id_foreign` (`product_id`),
  ADD KEY `category_product_category_id_foreign` (`category_id`);

--
-- Indexes for table `le_category_translations`
--
ALTER TABLE `le_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_translations_category_id_foreign` (`category_id`),
  ADD KEY `category_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_configurations`
--
ALTER TABLE `le_configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_countries`
--
ALTER TABLE `le_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_languages`
--
ALTER TABLE `le_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_menus`
--
ALTER TABLE `le_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menus_menu_group_id_foreign` (`menu_group_id`);

--
-- Indexes for table `le_menu_groups`
--
ALTER TABLE `le_menu_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_migrations`
--
ALTER TABLE `le_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_oauth_access_tokens`
--
ALTER TABLE `le_oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `le_oauth_auth_codes`
--
ALTER TABLE `le_oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_oauth_clients`
--
ALTER TABLE `le_oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `le_oauth_personal_access_clients`
--
ALTER TABLE `le_oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `le_oauth_refresh_tokens`
--
ALTER TABLE `le_oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `le_orders`
--
ALTER TABLE `le_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_order_status_id_foreign` (`order_status_id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_shipping_address_id_foreign` (`shipping_address_id`),
  ADD KEY `orders_billing_address_id_foreign` (`billing_address_id`);

--
-- Indexes for table `le_order_histories`
--
ALTER TABLE `le_order_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_histories_order_status_id_foreign` (`order_status_id`),
  ADD KEY `order_histories_order_id_foreign` (`order_id`);

--
-- Indexes for table `le_order_product`
--
ALTER TABLE `le_order_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_product_order_id_foreign` (`order_id`),
  ADD KEY `order_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_order_product_variations`
--
ALTER TABLE `le_order_product_variations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_product_variations_order_id_foreign` (`order_id`),
  ADD KEY `order_product_variations_product_id_foreign` (`product_id`),
  ADD KEY `order_product_variations_attribute_id_foreign` (`attribute_id`),
  ADD KEY `order_product_variations_attribute_dropdown_option_id_foreign` (`attribute_dropdown_option_id`);

--
-- Indexes for table `le_order_return_products`
--
ALTER TABLE `le_order_return_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_return_products_order_return_request_id_foreign` (`order_return_request_id`),
  ADD KEY `order_return_products_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_order_return_requests`
--
ALTER TABLE `le_order_return_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_return_requests_order_id_foreign` (`order_id`);

--
-- Indexes for table `le_order_statuses`
--
ALTER TABLE `le_order_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_pages`
--
ALTER TABLE `le_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_page_translations`
--
ALTER TABLE `le_page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_slug_unique` (`slug`),
  ADD KEY `page_translations_page_id_foreign` (`page_id`),
  ADD KEY `page_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_password_resets`
--
ALTER TABLE `le_password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `le_permissions`
--
ALTER TABLE `le_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `le_permission_role`
--
ALTER TABLE `le_permission_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_role_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `le_products`
--
ALTER TABLE `le_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_product_attribute_integer_values`
--
ALTER TABLE `le_product_attribute_integer_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_attribute_integer_values_attribute_id_foreign` (`attribute_id`),
  ADD KEY `product_attribute_integer_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_downloadable_urls`
--
ALTER TABLE `le_product_downloadable_urls`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_downloadable_urls_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_images`
--
ALTER TABLE `le_product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_images_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property`
--
ALTER TABLE `le_product_property`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_property_id_foreign` (`property_id`),
  ADD KEY `product_property_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_boolean_values`
--
ALTER TABLE `le_product_property_boolean_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_boolean_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_boolean_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_datetime_values`
--
ALTER TABLE `le_product_property_datetime_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_datetime_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_datetime_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_decimal_values`
--
ALTER TABLE `le_product_property_decimal_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_decimal_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_decimal_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_integer_values`
--
ALTER TABLE `le_product_property_integer_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_integer_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_integer_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_text_values`
--
ALTER TABLE `le_product_property_text_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_text_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_text_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_property_varchar_values`
--
ALTER TABLE `le_product_property_varchar_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_property_varchar_values_property_id_foreign` (`property_id`),
  ADD KEY `product_property_varchar_values_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_product_reviews`
--
ALTER TABLE `le_product_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_reviews_product_id_foreign` (`product_id`),
  ADD KEY `product_reviews_user_id_foreign` (`user_id`);

--
-- Indexes for table `le_product_variations`
--
ALTER TABLE `le_product_variations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_variations_variation_id_foreign` (`variation_id`),
  ADD KEY `product_variations_product_id_foreign` (`product_id`);

--
-- Indexes for table `le_promotions`
--
ALTER TABLE `le_promotions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_properties`
--
ALTER TABLE `le_properties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `properties_identifier_unique` (`identifier`);

--
-- Indexes for table `le_property_dropdown_options`
--
ALTER TABLE `le_property_dropdown_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `property_dropdown_options_property_id_foreign` (`property_id`);

--
-- Indexes for table `le_property_dropdown_option_translations`
--
ALTER TABLE `le_property_dropdown_option_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pdt` (`property_dropdown_option_id`),
  ADD KEY `property_dropdown_option_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_property_translations`
--
ALTER TABLE `le_property_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `property_translations_identifier_unique` (`identifier`),
  ADD KEY `property_translations_property_id_foreign` (`property_id`),
  ADD KEY `property_translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `le_related_products`
--
ALTER TABLE `le_related_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `related_products_product_id_foreign` (`product_id`),
  ADD KEY `related_products_related_id_foreign` (`related_id`);

--
-- Indexes for table `le_roles`
--
ALTER TABLE `le_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_site_currencies`
--
ALTER TABLE `le_site_currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_states`
--
ALTER TABLE `le_states`
  ADD PRIMARY KEY (`id`),
  ADD KEY `states_country_id_foreign` (`country_id`);

--
-- Indexes for table `le_subscribes`
--
ALTER TABLE `le_subscribes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_tax_groups`
--
ALTER TABLE `le_tax_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_tax_rates`
--
ALTER TABLE `le_tax_rates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_users`
--
ALTER TABLE `le_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `le_user_groups`
--
ALTER TABLE `le_user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `le_user_user_group`
--
ALTER TABLE `le_user_user_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_user_group_user_id_foreign` (`user_id`),
  ADD KEY `user_user_group_user_group_id_foreign` (`user_group_id`);

--
-- Indexes for table `le_wishlists`
--
ALTER TABLE `le_wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlists_user_id_foreign` (`user_id`),
  ADD KEY `wishlists_product_id_foreign` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `le_addresses`
--
ALTER TABLE `le_addresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_admin_users`
--
ALTER TABLE `le_admin_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `le_attributes`
--
ALTER TABLE `le_attributes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_attribute_dropdown_options`
--
ALTER TABLE `le_attribute_dropdown_options`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_attribute_dropdown_option_translations`
--
ALTER TABLE `le_attribute_dropdown_option_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_attribute_product`
--
ALTER TABLE `le_attribute_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_attribute_translations`
--
ALTER TABLE `le_attribute_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_banners`
--
ALTER TABLE `le_banners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `le_categories`
--
ALTER TABLE `le_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `le_category_filters`
--
ALTER TABLE `le_category_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_category_product`
--
ALTER TABLE `le_category_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `le_category_translations`
--
ALTER TABLE `le_category_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_configurations`
--
ALTER TABLE `le_configurations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `le_countries`
--
ALTER TABLE `le_countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `le_languages`
--
ALTER TABLE `le_languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `le_menus`
--
ALTER TABLE `le_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `le_menu_groups`
--
ALTER TABLE `le_menu_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `le_migrations`
--
ALTER TABLE `le_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `le_oauth_clients`
--
ALTER TABLE `le_oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `le_oauth_personal_access_clients`
--
ALTER TABLE `le_oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `le_orders`
--
ALTER TABLE `le_orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_histories`
--
ALTER TABLE `le_order_histories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_product`
--
ALTER TABLE `le_order_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_product_variations`
--
ALTER TABLE `le_order_product_variations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_return_products`
--
ALTER TABLE `le_order_return_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_return_requests`
--
ALTER TABLE `le_order_return_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_order_statuses`
--
ALTER TABLE `le_order_statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `le_pages`
--
ALTER TABLE `le_pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `le_page_translations`
--
ALTER TABLE `le_page_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_permissions`
--
ALTER TABLE `le_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_permission_role`
--
ALTER TABLE `le_permission_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_products`
--
ALTER TABLE `le_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `le_product_attribute_integer_values`
--
ALTER TABLE `le_product_attribute_integer_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_downloadable_urls`
--
ALTER TABLE `le_product_downloadable_urls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_images`
--
ALTER TABLE `le_product_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `le_product_property`
--
ALTER TABLE `le_product_property`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_property_boolean_values`
--
ALTER TABLE `le_product_property_boolean_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_property_datetime_values`
--
ALTER TABLE `le_product_property_datetime_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_property_decimal_values`
--
ALTER TABLE `le_product_property_decimal_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_property_integer_values`
--
ALTER TABLE `le_product_property_integer_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `le_product_property_text_values`
--
ALTER TABLE `le_product_property_text_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_property_varchar_values`
--
ALTER TABLE `le_product_property_varchar_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_reviews`
--
ALTER TABLE `le_product_reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_product_variations`
--
ALTER TABLE `le_product_variations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_promotions`
--
ALTER TABLE `le_promotions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_properties`
--
ALTER TABLE `le_properties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `le_property_dropdown_options`
--
ALTER TABLE `le_property_dropdown_options`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `le_property_dropdown_option_translations`
--
ALTER TABLE `le_property_dropdown_option_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_property_translations`
--
ALTER TABLE `le_property_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_related_products`
--
ALTER TABLE `le_related_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_roles`
--
ALTER TABLE `le_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `le_site_currencies`
--
ALTER TABLE `le_site_currencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `le_states`
--
ALTER TABLE `le_states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_subscribes`
--
ALTER TABLE `le_subscribes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_tax_groups`
--
ALTER TABLE `le_tax_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_tax_rates`
--
ALTER TABLE `le_tax_rates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_users`
--
ALTER TABLE `le_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_user_groups`
--
ALTER TABLE `le_user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_user_user_group`
--
ALTER TABLE `le_user_user_group`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `le_wishlists`
--
ALTER TABLE `le_wishlists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `le_addresses`
--
ALTER TABLE `le_addresses`
  ADD CONSTRAINT `addresses_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `le_countries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `le_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_admin_users`
--
ALTER TABLE `le_admin_users`
  ADD CONSTRAINT `admin_users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `le_roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_attribute_dropdown_options`
--
ALTER TABLE `le_attribute_dropdown_options`
  ADD CONSTRAINT `attribute_dropdown_options_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `le_attributes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_attribute_dropdown_option_translations`
--
ALTER TABLE `le_attribute_dropdown_option_translations`
  ADD CONSTRAINT `adt` FOREIGN KEY (`attribute_dropdown_option_id`) REFERENCES `le_attribute_dropdown_options` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attribute_dropdown_option_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_attribute_product`
--
ALTER TABLE `le_attribute_product`
  ADD CONSTRAINT `attribute_product_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `le_attributes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attribute_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_attribute_translations`
--
ALTER TABLE `le_attribute_translations`
  ADD CONSTRAINT `attribute_translations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `le_attributes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attribute_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_category_filters`
--
ALTER TABLE `le_category_filters`
  ADD CONSTRAINT `category_filters_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `le_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_category_product`
--
ALTER TABLE `le_category_product`
  ADD CONSTRAINT `category_product_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `le_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_category_translations`
--
ALTER TABLE `le_category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `le_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_menus`
--
ALTER TABLE `le_menus`
  ADD CONSTRAINT `menus_menu_group_id_foreign` FOREIGN KEY (`menu_group_id`) REFERENCES `le_menu_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_orders`
--
ALTER TABLE `le_orders`
  ADD CONSTRAINT `orders_billing_address_id_foreign` FOREIGN KEY (`billing_address_id`) REFERENCES `le_addresses` (`id`),
  ADD CONSTRAINT `orders_order_status_id_foreign` FOREIGN KEY (`order_status_id`) REFERENCES `le_order_statuses` (`id`),
  ADD CONSTRAINT `orders_shipping_address_id_foreign` FOREIGN KEY (`shipping_address_id`) REFERENCES `le_addresses` (`id`),
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `le_users` (`id`);

--
-- Constraints for table `le_order_histories`
--
ALTER TABLE `le_order_histories`
  ADD CONSTRAINT `order_histories_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `le_orders` (`id`),
  ADD CONSTRAINT `order_histories_order_status_id_foreign` FOREIGN KEY (`order_status_id`) REFERENCES `le_order_statuses` (`id`);

--
-- Constraints for table `le_order_product`
--
ALTER TABLE `le_order_product`
  ADD CONSTRAINT `order_product_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `le_orders` (`id`),
  ADD CONSTRAINT `order_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_order_product_variations`
--
ALTER TABLE `le_order_product_variations`
  ADD CONSTRAINT `order_product_variations_attribute_dropdown_option_id_foreign` FOREIGN KEY (`attribute_dropdown_option_id`) REFERENCES `le_attribute_dropdown_options` (`id`),
  ADD CONSTRAINT `order_product_variations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `le_attributes` (`id`),
  ADD CONSTRAINT `order_product_variations_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `le_orders` (`id`),
  ADD CONSTRAINT `order_product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_order_return_products`
--
ALTER TABLE `le_order_return_products`
  ADD CONSTRAINT `order_return_products_order_return_request_id_foreign` FOREIGN KEY (`order_return_request_id`) REFERENCES `le_order_return_requests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_return_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_order_return_requests`
--
ALTER TABLE `le_order_return_requests`
  ADD CONSTRAINT `order_return_requests_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `le_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_page_translations`
--
ALTER TABLE `le_page_translations`
  ADD CONSTRAINT `page_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `le_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_permission_role`
--
ALTER TABLE `le_permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `le_permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `le_roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_attribute_integer_values`
--
ALTER TABLE `le_product_attribute_integer_values`
  ADD CONSTRAINT `product_attribute_integer_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `le_attributes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_attribute_integer_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_downloadable_urls`
--
ALTER TABLE `le_product_downloadable_urls`
  ADD CONSTRAINT `product_downloadable_urls_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_images`
--
ALTER TABLE `le_product_images`
  ADD CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property`
--
ALTER TABLE `le_product_property`
  ADD CONSTRAINT `product_property_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_boolean_values`
--
ALTER TABLE `le_product_property_boolean_values`
  ADD CONSTRAINT `product_property_boolean_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_boolean_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_datetime_values`
--
ALTER TABLE `le_product_property_datetime_values`
  ADD CONSTRAINT `product_property_datetime_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_datetime_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_decimal_values`
--
ALTER TABLE `le_product_property_decimal_values`
  ADD CONSTRAINT `product_property_decimal_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_decimal_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_integer_values`
--
ALTER TABLE `le_product_property_integer_values`
  ADD CONSTRAINT `product_property_integer_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_integer_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_text_values`
--
ALTER TABLE `le_product_property_text_values`
  ADD CONSTRAINT `product_property_text_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_text_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_property_varchar_values`
--
ALTER TABLE `le_product_property_varchar_values`
  ADD CONSTRAINT `product_property_varchar_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_property_varchar_values_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_product_reviews`
--
ALTER TABLE `le_product_reviews`
  ADD CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `le_users` (`id`);

--
-- Constraints for table `le_product_variations`
--
ALTER TABLE `le_product_variations`
  ADD CONSTRAINT `product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_variations_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_property_dropdown_options`
--
ALTER TABLE `le_property_dropdown_options`
  ADD CONSTRAINT `property_dropdown_options_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_property_dropdown_option_translations`
--
ALTER TABLE `le_property_dropdown_option_translations`
  ADD CONSTRAINT `pdt` FOREIGN KEY (`property_dropdown_option_id`) REFERENCES `le_property_dropdown_options` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `property_dropdown_option_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_property_translations`
--
ALTER TABLE `le_property_translations`
  ADD CONSTRAINT `property_translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `le_languages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `property_translations_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `le_properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_related_products`
--
ALTER TABLE `le_related_products`
  ADD CONSTRAINT `related_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `related_products_related_id_foreign` FOREIGN KEY (`related_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_states`
--
ALTER TABLE `le_states`
  ADD CONSTRAINT `states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `le_countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_user_user_group`
--
ALTER TABLE `le_user_user_group`
  ADD CONSTRAINT `user_user_group_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `le_user_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_user_group_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `le_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `le_wishlists`
--
ALTER TABLE `le_wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `le_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `le_users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
